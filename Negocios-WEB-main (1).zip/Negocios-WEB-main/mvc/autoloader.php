<?php
/**
 * PHP Version 7.2
 *
 * @category Public
 * @package  Controllers
 * @author   Orlando J Betancourth <orlando.betancourth@gmail.com>
 * @license  MIT http://
 * @version  CVS:1.0.0
 * @link     http://
 */

//define("CLASS_DIR", "src" . DIRECTORY_SEPARATOR);
//set_include_path(CLASS_DIR . PATH_SEPARATOR . get_include_path());
//spl_autoload_extensions('.control.php,.mw.php,.model.php,.class.php');
//spl_autoload_register();
?>
