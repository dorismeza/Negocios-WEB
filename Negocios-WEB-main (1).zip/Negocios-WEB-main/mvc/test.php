<?php
// require_once "autoloader.php";
// session_start();

// \Utilities\Site::configure();

// class testConn extends \Dao\Table
// {
//     public static function test()
//     {
//         $data = self::obtenerRegistros("select * from usuarios;", array());
//         print_r($data);
//         die();
//     }
// }

// testConn::test();
print_r(apache_get_modules());
?>
