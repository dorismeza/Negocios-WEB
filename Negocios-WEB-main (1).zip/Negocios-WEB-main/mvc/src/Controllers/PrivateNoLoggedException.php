<?php
namespace Controllers;
use Exception;

class PrivateNoLoggedException extends Exception
{

}
?>
