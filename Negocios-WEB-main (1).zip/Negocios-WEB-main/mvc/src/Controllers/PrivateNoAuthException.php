<?php
namespace Controllers;
use Exception;

class PrivateNoAuthException extends Exception
{

}
?>
